﻿//define global namespace
var l2s = l2s || {};
//Change these URL when deploye to different env
l2s.k2home = "https://qbel2smtelsql02.redmond.corp.microsoft.com/Designer/Runtime/Form/QBE.L2S.smf.Main/"
l2s.userProfileUrl = "https://qbel2smtelsql02.redmond.corp.microsoft.com/Designer/Runtime/Form/QBE.L2S.sfm.GODDP-UserProfile/";
l2s.uatPortalUrl = 'https://microsoft.sharepoint.com/teams/QBE4/support/uat/Pages/L2S-User-Feedback.aspx';
//Consider this as a main function to call other functions
(function () {
    document.addEventListener('DOMContentLoaded', function () {
        var navObj = document.getElementById('leftNav');
        l2s.createMenuItem(navObj);
        l2s.itemClickHandler(l2s.k2home);
        var UserProfile = document.getElementById("UserProfile");
        if (UserProfile != null) {
            document.getElementById("UserProfile").onclick = function () {
                var iframe = document.getElementById('homeIframe');
                iframe.setAttribute('src', l2s.userProfileUrl);
            }
        }
        $("#Region input[type='radio']").change(function () {
            if ($(this).is(':checked')) {
                $(this).attr("checked", "checked");
            } else {
                $(this).removeAttr("checked");
            }
        });
        $("#60DayNotiForm input[type='checkbox']").change(function () {
            if ($(this).is(':checked')) {
                $(this).attr("checked", "checked").val("true");
            } else {
                $(this).removeAttr("checked").val("false");
            }
        });
        $('#WhenDealClose').kendoDatePicker({
            format: "MM/dd/yyyy"
        }).parent().parent().css({ "width": "97%" });
        var datepicker = $("#WhenDealClose").data("kendoDatePicker");
        $('#WhenDealClose').focus(function () {
            datepicker.open();
        });
        $("#NeedHelp").change(function () {
            if (!$("#NeedHelp").is(':checked')) {
                $("#60DayNotiForm input[type='checkbox']").removeAttr("checked").val("false");
            }
        });
        if ($("#NeedHelp").is(':checked')) {
            $("#moreInfo").addClass("in").attr("aria-expanded", true);
        } else {
            $("#moreInfo").removeClass("in").removeAttr("aria-expanded");
        }
    }, false);
})(jQuery);