﻿//define global namespace
var l2s = l2s || {};

//define an arry of object menu items.
l2s.leftMenuItems = [
    {
        url: l2s.k2home,
        description: 'Home',
        img: '/images/icons/home.png',
        isDoc: 'no',
    },
    {
        url: "/Documents/L2S%20User%20Guide.docx",
        description: 'User Guide',
        img: '/images/icons/guide.png',
        isDoc: 'yes',
    },
     {
         url: l2s.uatPortalUrl,
         description: 'Report Issue/Feedback',
         img: '/images/icons/issue.png',
         isDoc: 'yes',
     }
];

l2s.itemClickHandler = function (url) {
    if (window.location.href.toLocaleLowerCase().indexOf("servicerequests") < 0) {
        console.log("l2s: item click: " + url);
        var iframe = document.getElementById('homeIframe');
        iframe.setAttribute('src', url);
    }
}

l2s.createImage = function (src) {
    var img = document.createElement('img');
    img.setAttribute('src', src);
    return img;
}

l2s.createListItem = function (desc) {
    var li = document.createElement('li');
    li.setAttribute('class', 'menuItem');
    li.setAttribute('title', desc);
    return li;
}

l2s.createDocLink = function (ele) {
    var link = document.createElement('a');
    link.setAttribute('href', ele.url);
    link.appendChild(l2s.createImage(ele.img));

    var li = l2s.createListItem(ele.description);
    li.appendChild(link);
    return li;
}

l2s.createLink = function (ele) {
    var li = l2s.createListItem(ele.description);
    li.addEventListener('click', function () { l2s.itemClickHandler(ele.url) });
    li.appendChild(l2s.createImage(ele.img));
    return li;
}

l2s.createMenuItem = function (parentDiv) {
    var ul = document.createElement('ul');
    ul.setAttribute('class', 'menu');

    l2s.leftMenuItems.forEach(function (ele, idx) {
        var li;
        if (ele.isDoc == 'yes')
            li = l2s.createDocLink(ele);
        else
            li = l2s.createLink(ele);

        ul.appendChild(li);
    })
    parentDiv.appendChild(ul);
}